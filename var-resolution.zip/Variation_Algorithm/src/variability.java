import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.xml.sax.SAXException;

public class variability {
	static String variant;
	static List<Document> documents = new ArrayList<Document>(); 
	static String[] variants = new String[] {"AutomaticWiperWithRainSensor", "RearWiper","WiperWithStalks"}; 
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String variability = "Variability";
        String target = "TARGET-REF";
        String nextTargetNode = "IDENTIFIABLE-TARGET-REF";
        Main main = new Main();
		  File file = new File("C:\\Users\\mar03\\Desktop\\demo-east-adl\\demo2\\CarWiper-three.eaxml");
	      Document doc; Document doc1; Document doc2; Document doc3;
	      DocumentBuilderFactory dbfactory = DocumentBuilderFactory.newInstance();
	      try {
			DocumentBuilder dbBuilder = dbfactory.newDocumentBuilder();
			//Creating separate documents for all variants to avoid data conflicts between documents/variants
			doc1 = dbBuilder.parse(file); doc2 = dbBuilder.parse(file); doc3 = dbBuilder.parse(file);
			documents.add(doc1); documents.add(doc2); documents.add(doc3);
			
			for(int x = 0; x < variants.length; x++) {
				variant = variants[x];
				doc = documents.get(x);
				//Clearing all the variables before using them to avoid conflicts with already stored data
				main.design_func.clear();
                main.valid_events.clear();
                main.design_prototype.clear();
                main.analysis_func.clear();
                main.analysis_element.clear();
                main.design_element.clear();
                main.hardware_component.clear();
                main.hardware_element.clear();
                main.inValidConstraints.clear();
                main.inValidEvents.clear();
                main.list.clear();
                main.valid_events.clear();
                main.analysis = 0;
                main.hardware = 0;
                main.design = 0;
                main.eventCount = 0;
                main.childNodes = null;
                main.timingChild = null;
                //Calling function defined in main file to find variability 
				main.FindVariability(doc.getChildNodes(), variability, variant, target, nextTargetNode, doc);
			
			}
	} catch (ParserConfigurationException e) {
     e.printStackTrace();
 } catch (SAXException e) {
     e.printStackTrace();
 } catch (IOException e) {
     e.printStackTrace();
 } 
	}

}
