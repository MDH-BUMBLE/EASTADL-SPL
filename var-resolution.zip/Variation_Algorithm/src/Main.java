import java.io.File;
import java.io.IOException;
import java.io.StringWriter;
import java.util.*;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import javax.lang.model.util.Elements;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Result;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;
import org.xml.sax.SAXException;

public class Main {
	
	static int analysis;
    static int hardware;
    static int design;
    static int eventCount;
	static NodeList childNodes;
	static NodeList timingChild;
    static boolean isValidElement = false;
    static boolean isValidChild = false;
    static boolean isValidEvent = false;
    static String variant;
    static String analysisType = "ANALYSIS-FUNCTION-TYPE";
    static String hardwareType = "HARDWARE-COMPONENT-TYPE";
    static String designType = "DESIGN-FUNCTION-TYPE";
    static ArrayList<String> list=new ArrayList<String>();
    static List<String> inValidEvents =new ArrayList<>();
    static ArrayList<String> inValidConstraints =new ArrayList<>();
    static HashMap<String, String> valid_events = new HashMap<>();
	static HashMap<String, String> design_func = new HashMap<>();
	static HashMap<String, String> design_prototype = new HashMap<>();
	static HashMap<String, String> analysis_func = new HashMap<>();
	static HashMap<String, String> hardware_component = new HashMap<>();
	static ArrayList<String> analysis_element =new ArrayList<String>();
	static ArrayList<String> hardware_element =new ArrayList<String>();
	static ArrayList<String> design_element =new ArrayList<String>();
	
	//Function to find variability associated with a specific variant
	public static void FindVariability(NodeList nodelist, String variability, String variants,String targetNode, String nextTargetNode, Document doc) {
		// TODO Auto-generated method stub
		int i=0;
		String targetValue;
		variant = variants;
		while(i<nodelist.getLength()){
			Node node = nodelist.item(i);
			if(node.hasChildNodes()) {
				if(node.getParentNode().getNodeName().equalsIgnoreCase(variability)) {
				    if(node.getChildNodes().getLength()==1) {
				    	if((node.getNodeName()=="SHORT-NAME") && (node.getTextContent().equalsIgnoreCase(variant))){
				    	  targetValue = node.getTextContent();
				    	  System.out.println("\nVariability:- Node Name: "+ node.getParentNode().getNodeName()); 
				    	  System.out.println("Variability:- Node Value: "+ targetValue);
				    	  //If variability is associated with the variant then find its configuration decision
				    	  FindConfigurationDecision(node.getParentNode().getChildNodes(), targetNode, nextTargetNode,  doc);
				          }
				    	else {
				    		//Removing all variabilities, not associated with the specific variant
				    		node.getParentNode().getParentNode().removeChild(node.getParentNode());
				    		SaveDocument(doc);
				    	}
				    } }
				FindVariability(node.getChildNodes(), variability, variants, targetNode, nextTargetNode, doc);
				}   i++;  }
			}
	
	private static void FindConfigurationDecision(NodeList nodelist, String targetNode, String nextTargetNode, Document doc) {
		// TODO Auto-generated method stub
		int i=0;
		String targetValue;
		while(i<nodelist.getLength()){
			Node node = nodelist.item(i); 
			if(node.hasChildNodes()) {
				if(node.getChildNodes().getLength()==1) {
					if(node.getNodeName().equalsIgnoreCase(targetNode)) {
						  System.out.println("\nConfiguration Decision:- Node Name: "+ node.getNodeName());  
						  System.out.println("Configuration Decision:- Node Value: "+ node.getTextContent());
						  if(node.hasAttributes()) {
							  //Getting target property to find path of associated feature
							  String type = node.getAttributes().getNamedItem("TYPE").getNodeValue();
							  System.out.println("Configuration Decision:- Node Type: "+ type);
							  String[] parts = node.getTextContent().split("/");
							  targetValue = parts[parts.length-1];
							  String subpkg = parts[parts.length-2];
							  String pkg = parts[parts.length-4];
							  //Giving feature package name to function to get exact location of the feature in the file
							  childNodes = FindPackage(doc.getChildNodes(), subpkg, pkg,  doc);
							  //Finding realization propoerty in the associated feature
							  FindRealization(childNodes, "IDENTIFIABLE-TARGET-REF",targetValue, type, doc);
						  }  }	}
				FindConfigurationDecision(node.getChildNodes(),targetNode,nextTargetNode ,doc);
				}   i++;  }
			}
	
	private static void FindRealization(NodeList nodelist, String targetElement, String textNode, String type, Document doc) {
		// TODO Auto-generated method stub
		int i=0;
		while(i<nodelist.getLength()){
			Node node = nodelist.item(i); 
			if(node.hasChildNodes()) {
				if(node.getChildNodes().getLength()==1) {
					if((node.getNodeName()=="SHORT-NAME") && (node.getParentNode().getNodeName().equalsIgnoreCase(type))) {
						 if(((node.getTextContent().toLowerCase()).contains(textNode.toLowerCase())) 
								|| ((textNode.toLowerCase()).contains(node.getTextContent().toLowerCase()))) 
						 {
						  Element element = (Element) node.getParentNode();
						  Node targetNode = element.getElementsByTagName(targetElement).item(0);
						  System.out.println("\nRealization:- Node Name: "+ targetNode.getNodeName());  
						  System.out.println("Realization:- Node Content: "+ targetNode.getTextContent());
						  if(targetNode.hasAttributes()) {
							//Getting target property to find path of associated type element
							  String typeElement = targetNode.getAttributes().getNamedItem("TYPE").getNodeValue();
							  System.out.println("Realization:- Node Type: "+ typeElement);
							  String[] parts = targetNode.getTextContent().split("/");
							  String nodeName = parts[parts.length-1];
							  String subpkg = parts[parts.length-2];
			 				  String pkg = parts[parts.length-3];
			 				//Giving package name of type element to function to get exact location of the this type element in the file
			 				 childNodes = FindPackage(doc.getChildNodes(), pkg, null,  doc);
			 				
							 FindDesignFunctionType(childNodes, typeElement, doc);
							  break;
						  }	}
						 else {
							 node.getParentNode().getParentNode().removeChild(node.getParentNode());
							 SaveDocument(doc);
						 }
					} 
					}	
				FindRealization(node.getChildNodes(),targetElement,textNode, type  ,doc);
				}   i++;  }
	}	
	
	private static void FindDesignFunctionType(NodeList nodelist, String type, Document doc) {
			// TODO Auto-generated method stub
			int i=0;
			int count = 0;
			int targetLength = 0;
			while(i<nodelist.getLength()){
				Node node = nodelist.item(i);
				if(node.hasChildNodes()) {
					    if(node.getChildNodes().getLength()==1) {
					    	//Getting DesignFunctionType element
					    	if((node.getNodeName()=="SHORT-NAME") && (node.getParentNode().getNodeName().equalsIgnoreCase(type))) {
					    		
					    		String[] parts = node.getTextContent().split("_");
					    		String name = String.join("", parts);
					    		String[] splitted = name.split("-");
					    		//Checking if after splitting and merging is this node associted with the variant
					    		if(splitted[1].equalsIgnoreCase(variant)) {
					    			//Finding design function type
					    			FindDesignFunctionPrototype(node.getParentNode().getChildNodes(), "TYPE-TREF", doc);
					          break;
						  }
					    		else {
					    			//Removing this node as its not associted with the specific node
					    			node.getParentNode().getParentNode().removeChild(node.getParentNode());
					    			SaveDocument(doc);
					    		}	
					    	}
					    	//Getting hardwareComponentType element
					    	else if((node.getNodeName()=="SHORT-NAME") && (node.getParentNode().getNodeName().equalsIgnoreCase("HARDWARE-COMPONENT-PROTOTYPE"))) {
					    		String[] parts = node.getTextContent().split("_");
					    		String name = String.join("", parts);
					    		//If after splitting and merging this node does not matches with the variant, then remove it
					    		if(!(name.equalsIgnoreCase(variant))) {
					    			node.getParentNode().getParentNode().removeChild(node.getParentNode());
					    			SaveDocument(doc);
						  }	
					    	}
					    	//Getting AnalysisFunctionType element
					    	else if((node.getNodeName()=="SHORT-NAME") && (node.getParentNode().getNodeName().equalsIgnoreCase("ANALYSIS-FUNCTION-PROTOTYPE"))) {
					    		 //if the length of both variant and the current node is >=3 then target length is 3
					    		 String[] targetStr = variant.split("(?=\\p{Upper})");
					    		 //Splitting varaint and node after every uppercase letter
			            		 String[] nodeStr = node.getTextContent().split("(?=\\p{Upper})");
			            		 if((targetStr.length>=3) && (nodeStr.length>=3)) {
			            			 targetLength = 3;
			            		 }
			            		 else {
			            			 targetLength = 2;
			            		 }
			            		    //here we are checking that how many words match with specific varaint 
			            			for(int j=0; j<nodeStr.length; j++) {
			            				if(variant.contains(nodeStr[j])) {
			            					count++;
			            				}
			            			}      //if the length of node and varaint is 3 then at least 3 words should match 
			            			//otherwise if node or variant length is 2 words then at least 2 words should match, if they don't it means they are not associated with the variant
				            				if(!(count>=targetLength)) {
				            					node.getParentNode().getParentNode().removeChild(node.getParentNode());
								    			SaveDocument(doc);
				            				}
				            	
					    	}   	
					    }
					FindDesignFunctionType(node.getChildNodes(), type,doc);
					}   i++;  } }
		
	private static void FindDesignFunctionPrototype(NodeList nodelist, String targetElement, Document doc) {
			// TODO Auto-generated method stub
			int i=0;
			while(i<nodelist.getLength()){
				Node node = nodelist.item(i); 
				if(node.hasChildNodes()) {
					if(node.getChildNodes().getLength()==1) {
						if(node.getNodeName().equalsIgnoreCase(targetElement)) {
							  System.out.println("\nDesign Function Prototype:- Node Name: "+ node.getNodeName());  
							  System.out.println("Design Function Prototype:- Node Value: "+ node.getTextContent());
							  if(node.hasAttributes()) {
								//Getting target property to find path of associated design function type element
								  String type = node.getAttributes().getNamedItem("TYPE").getNodeValue();
								  System.out.println("Design Function Prototype:- Node Type: "+ type);
								  String[] parts = node.getTextContent().split("/");
								  String subpkg = parts[parts.length-2];
								  String pkg = parts[parts.length-3];
								  //Finding exact design function location in the file and passing its childnodes to the 
								  //next function which moves to that specific address and checks all of its childnodes
								  childNodes = FindPackage(doc.getChildNodes(), subpkg, pkg,  doc);
								  FindChildNodes(childNodes, type, doc);
								  break;
							  }	 }	}
					FindDesignFunctionPrototype(node.getChildNodes(),targetElement ,doc);
					}   i++;  }
		}
	 
	// same as find DesignFunctionType
	private static void FindChildNodes(NodeList nodelist, String type, Document doc) {
			// TODO Auto-generated method stub
			int i=0;
			while(i<nodelist.getLength()){
				Node node = nodelist.item(i);
				if(node.hasChildNodes()) {
					    if(node.getChildNodes().getLength()==1) {
					    	if(node.getNodeName()=="SHORT-NAME" && node.getParentNode().getNodeName().equalsIgnoreCase(type)) {
					    		String[] parts = node.getTextContent().split("-");
					    	    String name = String.join("", parts);
					    	 //   String[] splitted = name.split("-");
					    	    //After splitting and merging the node value, we are checking that if node starts with the digit, 
					    	    //if yes then get node value after digit
					    		if (Character.isDigit(name.charAt(0))){   
					    			String substring = name.substring(1);
					    		    if(substring.equalsIgnoreCase(variant)) {
					    		          FindParent(node.getTextContent(), doc.getChildNodes(),list,  doc);
					    		    	  break;
					    		   }
					    		    else {
					    		    	node.getParentNode().getParentNode().removeChild(node.getParentNode());
					    		    	SaveDocument(doc);
					    		    }
					    		}   }}
					    FindChildNodes(node.getChildNodes(), type, doc);
					}   i++;  }
		}
		
    private static void FindParent(String textNode, NodeList nodeList, ArrayList<String> list, Document doc) {
			// TODO Auto-generated method stub
			int i=0;
			while(i<nodeList.getLength()){
				Node node = nodeList.item(i);
				if(node.hasChildNodes()) {
					    if(node.getChildNodes().getLength()==1) {
					    	if((node.getParentNode().getNodeName().equalsIgnoreCase("DESIGN-FUNCTION-TYPE")) && (node.getTextContent().equalsIgnoreCase(textNode))) { 
					            //Function to get all design function prototypes 
					    		FindAllChild(node.getParentNode().getChildNodes(), "DESIGN-FUNCTION-PROTOTYPE" ,textNode,list,design_func, doc);
					    	    //function to count the number of analysis, design and hardware elements in the realization
					    	    FindRelizationCount(node.getParentNode().getChildNodes(), "IDENTIFIABLE-TARGET-REF");
					    		FindRealizationChild(node.getParentNode().getChildNodes(), "IDENTIFIABLE-TARGET-REF" ,analysis_func,hardware_component,design_prototype,variant, doc);
					    		break;
						  }  }   FindParent(textNode, node.getChildNodes(), list, doc);
				}   i++;  }
		}
		
	private static void FindRelizationCount(NodeList nodelist, String string) {
			// TODO Auto-generated method stub
			int i=0;
			while(i<nodelist.getLength()){
				Node node = nodelist.item(i);
				if(node.hasChildNodes()) {
					if(node.getChildNodes().getLength()==1) {
						if(node.getNodeName()==string) {
							//getting node type attribute to check the type of the node 
							String check = node.getAttributes().getNamedItem("TYPE").getNodeValue();
							if(check.equalsIgnoreCase("ANALYSIS-FUNCTION-PROTOTYPE")) {
								analysis++;}
	  				     	else if (check.equalsIgnoreCase("HARDWARE-COMPONENT-PROTOTYPE")) {
	  						    hardware++;}
	  					    else if (check.equalsIgnoreCase("DESIGN-FUNCTION-PROTOTYPE")) {
	  						   design++;}
						}	}
						FindRelizationCount(node.getChildNodes(), string);
				}   i++;  }
			}
	
	
	private static void FindRealizationChild(NodeList nodelist, String targetNode, HashMap<String, String> analysis_func,
			HashMap<String, String> hardware_component, HashMap<String, String> design_prototype, String targetPackage, Document doc) {
		// TODO Auto-generated method stub
		int i=0;
		while(i<nodelist.getLength()){
			Node node = nodelist.item(i);
			if(node.hasChildNodes()) {
				if(node.getChildNodes().getLength()==1) {
					if((node.getNodeName()==targetNode) && (node.getParentNode().getNodeName().equalsIgnoreCase("REALIZED-IREF"))) {
						String type = node.getAttributes().getNamedItem("TYPE").getNodeValue();
						//if node type is analysis function type then add it in the hashmap with node name and value
						if(type.equalsIgnoreCase("ANALYSIS-FUNCTION-PROTOTYPE")) {
							String[] parts = node.getTextContent().split("/");
						    String element = parts[parts.length-1];
						    String subpkg = parts[parts.length-3];
						    String pkg = parts[parts.length-4];
							analysis_func.put(element, node.getTextContent());
							//checking if analysis element added equals the total analysis element
							if(analysis==analysis_func.size()) {
								//Finding Analysis package and moving there
								childNodes = FindPackage(doc.getChildNodes(), subpkg, pkg,  doc);
								FindNode(childNodes,analysis_func, type, variant, analysisType,analysis_element, doc);
								
							} }
						//if node type is hardware component type then add it in the hashmap with node name and value
						else if(type.equalsIgnoreCase("HARDWARE-COMPONENT-PROTOTYPE")) {
							String[] parts = node.getTextContent().split("/");
						    String element = parts[parts.length-1];
						    String subpkg = parts[parts.length-3];
						    String pkg = parts[parts.length-4];
							hardware_component.put(element, node.getTextContent());
							//checking if hardware elements added equals the total analysis element
                            if(hardware==hardware_component.size()) {
                            	//Finding Hardware package and moving there
                            	childNodes = FindPackage(doc.getChildNodes(), subpkg, pkg,  doc);
                            	FindNode(childNodes,hardware_component, type, variant, hardwareType, hardware_element, doc);
							}  }  }
					
					else if((node.getNodeName()==targetNode) && (node.getParentNode().getNodeName().equalsIgnoreCase("REALIZED-BY-IREF"))) {
						String type = node.getAttributes().getNamedItem("TYPE").getNodeValue();
						//if node type is design function type then add it in the hashmap with node name and value
						if(type.equalsIgnoreCase("DESIGN-FUNCTION-PROTOTYPE")) {
							String[] parts = node.getTextContent().split("/");
						    String element = parts[parts.length-1];
						    String subpkg = parts[parts.length-3];
						    String pkg = parts[parts.length-4];
							design_prototype.put(element, node.getTextContent());
							//checking if design elements added equals the total analysis element
                            if(design==design_prototype.size()) {
                            	//Finding Design package and moving there
                            	childNodes = FindPackage(doc.getChildNodes(), subpkg, pkg,  doc);
                            	FindNode(childNodes,design_prototype, type, variant, designType, design_element, doc);
							}	}  }
					}
				 FindRealizationChild(node.getChildNodes(), targetNode ,analysis_func,hardware_component,design_prototype,targetPackage, doc);
			}   i++;  }
	}
	
	private static void FindNode(NodeList nodeList, HashMap<String, String> hashmap, String type, String targetNode, String targetType, ArrayList<String> targetElement, Document doc) {
		// TODO Auto-generated method stub
		int i=0;
		String name;
		int count = 0;
		int targetLength = 0;
		while(i<nodeList.getLength()){
			Node node = nodeList.item(i);
			if(node.hasChildNodes()) {
				    if(node.getChildNodes().getLength()==1) {
				    	//Traget type can be Analysis, Design or Hardware depending on when this function is called
				             if ((node.getNodeName().equalsIgnoreCase("SHORT-NAME")) && (node.getParentNode().getNodeName().equalsIgnoreCase(targetType))){
				        
				            	 if(node.getTextContent().contains("-")) {
				            		 String[] parts =  node.getTextContent().split("-");
				            		 name = String.join("", parts);
				            		 //Checking if node machtes with the variant
				            		 if(name.contains(targetNode)) 
				            				// || (targetNode.contains(name))) 
				            		 {
						            	 System.out.println("\nNode:- " + node.getTextContent());
							    		 System.out.println("Parent Node:-" + node.getParentNode().getNodeName());
							    		 FindNodeChild(node.getParentNode().getChildNodes(), type,  hashmap, targetType, targetElement,doc);
		   				                 break;
		   				            }
						            	 else {
							            	   node.getParentNode().getParentNode().removeChild(node.getParentNode());
							            	   SaveDocument(doc);
							             }
				            	 }
				            	 else {
				            		 String[] targetStr = variant.split("(?=\\p{Upper})");
				            		 String[] nodeStr = node.getTextContent().split("(?=\\p{Upper})");
				            		 if ((nodeStr.length>=3) && (targetStr.length>=3)) {
				            			 targetLength = 3;
				            		 }
				            		 else if((nodeStr.length==2) || (targetStr.length==2)) {
				            			 targetLength = 2;
				            		 }
				            		 
				            			for(int j=0; j<nodeStr.length; j++) {
				            				if(variant.contains(nodeStr[j])) {
				            					count++;
				            				}
				            			}
				            				if(count>=targetLength) {
				            					System.out.println("\nNode:- " + node.getTextContent());
									    		 System.out.println("Parent Node:-" + node.getParentNode().getNodeName());
									    		 FindNodeChild(node.getParentNode().getChildNodes(), type,  hashmap, targetType, targetElement,doc);
				   				                 break;
				            				}
				            				 else {
								            	   node.getParentNode().getParentNode().removeChild(node.getParentNode());
								            	   SaveDocument(doc);
								             }
				            	 }}
				    	}     
				    FindNode(node.getChildNodes(),hashmap, type, targetNode, targetType, targetElement,doc);
			}   i++;  }
	}

	
	private static void FindNodeChild(NodeList nodelist , String type, HashMap<String, String> hashmap, String targetType, ArrayList<String> targetElement, Document doc) {
		// TODO Auto-generated method stub
		int i=0;
		while(i<nodelist.getLength()){
			Node node = nodelist.item(i);
			if(node.hasChildNodes()) {
				if(node.getChildNodes().getLength()==1) {
					if((node.getNodeName()=="SHORT-NAME") && (node.getParentNode().getNodeName().equalsIgnoreCase(type))) {
						Element element = (Element) node.getParentNode();
						Node typeNode = element.getElementsByTagName("TYPE-TREF").item(0);
						int length = element.getElementsByTagName("TYPE-TREF").getLength();
						String typeValue = typeNode.getTextContent();
						String[] parts = typeValue.split("/");
						String pkg = parts[parts.length-3];
						String subpkg = parts[parts.length-2];
						String nodeName = parts[parts.length-1];
						//checking if the elements picked from realization match with the current node
						//if yes then add their associated element into the array otherwise remove them
						for (Entry<String, String> entry : hashmap.entrySet()) {
		        	    	if((node.getTextContent().toLowerCase()).equalsIgnoreCase((entry.getKey().toLowerCase()))) {
		        	    		targetElement.add(nodeName);
		        	    		isValidElement=true;
		        	    		} }
						
						    if(isValidElement==false) { 
						    	node.getParentNode().getParentNode().removeChild(node.getParentNode());
						    	SaveDocument(doc);
						    }
						    else {
						    	isValidElement=false;
						    }
						if(targetElement.size()==hashmap.size()) {
							childNodes = FindPackage(doc.getChildNodes(), subpkg, pkg,  doc);
							FindElement(childNodes,targetType, targetElement, doc);
							}
					}
				}
				FindNodeChild(node.getChildNodes(), type,  hashmap, targetType, targetElement,doc);
			}   i++;  }
	}	

	private static void FindElement(NodeList nodeList, String targetType,  ArrayList<String> targetElement, Document doc) {
		// TODO Auto-generated method stub
		int i=0;
		while(i<nodeList.getLength()){
			Node node = nodeList.item(i);
			if(node.hasChildNodes()) {
				    if(node.getChildNodes().getLength()==1) {
				    	if((node.getNodeName()=="SHORT-NAME") && (node.getParentNode().getNodeName().equalsIgnoreCase(targetType))) {
				    		//checking if the node equals with any of element in the array, if not then remove it
				    		for (int j = 0; j < targetElement.size(); j++) {
				    			 if(node.getTextContent().equalsIgnoreCase(targetElement.get(j))) {
				    				 isValidChild = true;
								} 	 
				    		} 
							 if(isValidChild==false) {
								 node.getParentNode().getParentNode().removeChild(node.getParentNode());
				            	  SaveDocument(doc);
						       }
						       else {
						    	   isValidChild=false;
						       }
				    			}
				    	} 
				    FindElement(node.getChildNodes(), targetType, targetElement, doc);
			}   i++;  }
		
	}
	
	private static void FindAllChild(NodeList nodelist, String targetNode, String textNode, ArrayList<String> list,  HashMap<String, String> design_func, Document doc) {
		// TODO Auto-generated method stub
		int i=0;
		while(i<nodelist.getLength()){
			Node node = nodelist.item(i);
			if(node.hasChildNodes()) {
				if(node.getNodeName() == targetNode) {
				  String subpkg = "Timings";
				  Element parentElement = (Element) node.getParentNode();
			   	  int length = parentElement.getElementsByTagName(targetNode).getLength();
				  Element element = (Element) node;
         		  Node eventName = element.getElementsByTagName("SHORT-NAME").item(0);
        		  Node eventType = element.getElementsByTagName("TYPE-TREF").item(0);
        	      design_func.put(eventName.getTextContent(), eventType.getTextContent());
        	      //adding all design function type into array
        	      int listLength = design_func.size();
        	      if(length == listLength) {
        	    	  //finding timing package 
        	    	  childNodes = FindPackage(doc.getChildNodes(), subpkg, null,  doc);
        	    	  //finding timing childnodes
        	    	  FindTimingChild(childNodes, textNode, design_func,valid_events, doc);
        	    	  timingChild = childNodes;
        	    	  RemoveTimingPackage(timingChild, variant, doc);
        	    	  
    	              } 
				}
				FindAllChild(node.getChildNodes(), targetNode ,textNode,list,design_func ,doc);
			}   i++;  }
		}
   
	private static void RemoveTimingPackage(NodeList nodelist, String variant, Document doc) {
		// TODO Auto-generated method stub
		int i=0;
		int count = 0;
		int targetLength = 2;
		while(i<nodelist.getLength()){
			Node node = nodelist.item(i); 
			if(node.hasChildNodes()) {
				if(node.getChildNodes().getLength()==1) {
					if((node.getParentNode().getNodeName().equalsIgnoreCase("EA-PACKAGE")) && (node.getNodeName().equalsIgnoreCase("SHORT-NAME"))) {
						
						if(node.getTextContent().contains("Timing")) {
							if(!(node.getTextContent().equalsIgnoreCase("TimingDataType")) && (!(node.getTextContent().equalsIgnoreCase("Timings")))){
							
									String[] targetStr = variant.split("(?=\\p{Upper})");
                            		String[] nodeStr = node.getTextContent().split("(?=\\p{Upper})");
                            		 if((targetStr.length>=3) && (nodeStr.length>=3)) {
   		                 			 targetLength = 3;
     		            		 } 
                            		 else {
		            			 targetLength = 2;
		            		 }
                            			for(int j=0; j<targetStr.length; j++) {
        		            				if((node.getTextContent()).contains(targetStr[j])) {
        		            					count++;
        		            				}
       		            			}
        		            			
        		            			if(count>=2) {
        		            			}
        		            			else {
        		            				node.getParentNode().getParentNode().removeChild(node.getParentNode());
        		            				SaveDocument(doc);
        		            			}	 
								 
							}
						}

					}
				}
				 RemoveTimingPackage(node.getChildNodes(), variant, doc);
				}   i++;  }
				}
		
	


	private static void FindTimingChild(NodeList nodelist, String textNode, HashMap<String, String> design_func, HashMap<String, String> valid_events,  Document doc) {
		// TODO Auto-generated method stub
		int i=0;
		int j=0;
		while(i<nodelist.getLength()){
			Node node = nodelist.item(i); 
			if(node.hasChildNodes()) {
				if(node.getChildNodes().getLength()==1) {
					//finding event function 
					if (node.getParentNode().getParentNode().getNodeName().equalsIgnoreCase("EVENT-FUNCTION")) {
						if (node.getNodeName()=="FUNCTION-PROTOTYPE-TARGET-REF") {
					
						Element eventParent = (Element) node.getParentNode().getParentNode();
		         		Node eventName = eventParent.getElementsByTagName("SHORT-NAME").item(0);
		        		String[] parts = node.getTextContent().split("/");
		        		String parentNode = parts[parts.length-2]; 
						String linkedEvent = parts[parts.length-1];
						//checking if the event node is linked with valid type element
						if(parentNode.equalsIgnoreCase(textNode)) {
		        	    for (Entry<String, String> entry : design_func.entrySet()) {
		        	    	if((linkedEvent.toLowerCase()).contains(entry.getKey().toLowerCase())) {
		        	    		isValidEvent = true;
		        	    		}
		    			}}
		        	    if(isValidEvent==false) {
		        	    //if event is invalid then remove this event and its associated constraints
		        	    	node.getParentNode().getParentNode().getParentNode().removeChild(node.getParentNode().getParentNode());
		        	    	RemoveInvalidConstraints(childNodes,eventName.getTextContent(), doc);
		        	    	RemoveExecutionTimeConstraint(childNodes, eventName.getTextContent(), doc);
		        	    	inValidConstraints.add(eventName.getTextContent());
					       }
					    else {
					    	   isValidEvent=false;
					       }
		        	    

					  }
						else {
							
						}	
					}  }
				FindTimingChild(node.getChildNodes(), textNode, design_func, valid_events,   doc);
				}   i++;  }
	}
	
	private static void RemoveInvalidConstraints(NodeList nodelist, String textNode, Document doc) {
		// TODO Auto-generated method stub
		int i=0;
		while(i<nodelist.getLength()){
			Node node = nodelist.item(i); 
			if(node.hasChildNodes()) {
				if(node.getChildNodes().getLength()==1) {
					if (node.getParentNode().getParentNode().getNodeName().equalsIgnoreCase("CONSTRAINTS")) {
		
							if(node.getParentNode().getNodeName().equalsIgnoreCase("PERIODIC-CONSTRAINT")) {
							if (node.getNodeName()=="EVENT-REF") {
				        		String[] parts = node.getTextContent().split("/");
				        		String parentNode = parts[parts.length-2]; 
								String linkedEvent = parts[parts.length-1];
								//Checking if the constraint is linked with the invalid event
								if(linkedEvent.equalsIgnoreCase(textNode)) {
								
									node.getParentNode().getParentNode().removeChild(node.getParentNode());
									SaveDocument(doc);
								}
							  }
						}	
					
					} }
				RemoveInvalidConstraints(node.getChildNodes(), textNode,  doc);
				}   i++;  }
	}
	
	private static void RemoveExecutionTimeConstraint(NodeList nodelist, String string, Document doc) {
		// TODO Auto-generated method stub
				int i=0;
				while(i<nodelist.getLength()){
					Node node = nodelist.item(i); 
					if(node.hasChildNodes()) {
						if(node.getChildNodes().getLength()==1) {
					//		if (node.getParentNode().getParentNode().getNodeName().equalsIgnoreCase("CONSTRAINTS")) {
								
								if(node.getParentNode().getNodeName().equalsIgnoreCase("EXECUTION-TIME-CONSTRAINT")) {
								if (node.getNodeName()=="SHORT-NAME") {
									//Checking if the constraint is linked with the invalid event
									 if(string.contains(node.getTextContent())) { 
									   node.getParentNode().getParentNode().removeChild(node.getParentNode());
									   SaveDocument(doc);
										}
								
							  }
						
							} 
							}
						RemoveExecutionTimeConstraint(node.getChildNodes(), string,  doc);
						}   
					i++;  }
		
	}


	private static void RemoveInValidEvents(NodeList nodelist, List<String> inValidEvents, Document doc) {
		// TODO Auto-generated method stub
        int i=0;
		while(i<nodelist.getLength()){
			Node node = nodelist.item(i);
			if(node.hasChildNodes()) {
				if(node.getNodeName()=="SHORT-NAME") {
				    if(node.getChildNodes().getLength()==1) {
				    	inValidEvents = inValidEvents.stream().distinct().collect(Collectors.toList());
				    	for (int j = 0; j < inValidEvents.size(); j++) {
				    		  if(node.getTextContent().equalsIgnoreCase(inValidEvents.get(j))) {
				    			node.getParentNode().getParentNode().removeChild(node.getParentNode());
				    		    SaveDocument(doc);
				    		  }
				    		}
				    	}
				    }
				RemoveInValidEvents(node.getChildNodes(), inValidEvents, doc);
				}   i++;  }
		
	}
	
	private static NodeList FindPackage(NodeList nodelist, String subpkg, String pkg,  Document doc) {
			// TODO Auto-generated method stub
			int i=0;
			while(i<nodelist.getLength()){
				Node node = nodelist.item(i);
				if(node.hasChildNodes()) {
					    if(node.getTextContent().equalsIgnoreCase(subpkg)) {
					    		System.out.println("\nPackage:- "+ pkg);
					    		System.out.println("SubPackage:- "+ subpkg);
					    		childNodes = node.getParentNode().getChildNodes();
					    		break;
						  }	
					FindPackage(node.getChildNodes(), subpkg, pkg,  doc);
					}   i++;  }
			return childNodes; }  
		
	    
	private static void SaveDocument(Document doc) {
		// TODO Auto-generated method stub
		
		try {
		DOMSource source = new DOMSource(doc);
		String path = "C:\\Users\\mar03\\Desktop\\demo-east-adl\\demo2\\CarWiper-"+variant+".eaxml";
		File file = new File(path);
	    Result result = new StreamResult(file);
	    TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = transformerFactory.newTransformer();
		transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
		transformer.setOutputProperty(OutputKeys.INDENT, "yes");
		transformer.transform(source, result);
		System.out.println("\nDocument Saved Successfully");
		} catch (TransformerConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TransformerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}


}


